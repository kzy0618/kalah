package kalah;

public class store extends Pits{
	
	public store(Player player) {
		owner = player;
		seeds = 0;
		identifier = 0;
	}
}
