package kalah;

public interface gameController {
	public void init();
	public void start();
}
